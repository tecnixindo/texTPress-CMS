<?php
include_once "functions.inc.php";

		$row_recent = $row_global;
		if (!file_exists('files/'.$path[0].'.txt') && $path[0] != '') {$row_recent = read_db('files/sample_home.txt',1,99);}
		$row_recent = array_sort($row_recent,6,SORT_DESC);

		foreach ($row_recent as $column_recent) {
			$column_recent[5] = date('D, d M Y - H:i',strtotime($column_recent[5]));
		}

	$pola0 = in_string('<!--start recent-->','<!--end recent-->',$template);
	$list = "";
$count_recent = 0;
	for ($i=0;$i<count($row_recent);$i++) {
		$pola1 = str_replace('[]','['.$i.']',$pola0);
		$list .= $pola1;
		if ($i >= 3 || $i >= count($row_recent)) {break;}
	}
		$template = str_replace($pola0,$list,$template);


$count_recent = 0;
foreach ($row_recent as $column_recent) {
	if (strlen($column_recent[3]) > 11 && !preg_match('/galeri|widget|halaman/i',$column_recent[2]) && !stristr($column_recent[1],$path[1]) && date('Y-m-d',strtotime($column_recent[5])) >= date('Y-m-d',mktime(0, 0, 0, date('m'), date('d')-10, date('Y'))) ) {
			$content_img = in_string('img src="','"',$column_recent[4]);
			if ($content_img == '') {$content_img = $abs_url."images/no_image.png";}
			$content = strip_tags(stripslashes($column_recent[4]),"<br>");
			$template = str_replace('{recent_permalink['.$count_recent.']}',$abs_url.$column_recent[2].'/'.$column_recent[1],$template);
			$template = str_replace('{recent_date['.$count_recent.']}',$column_recent[5],$template);
			$template = str_replace('{recent_title['.$count_recent.']}',stripslashes($column_recent[3]),$template);
			$template = str_replace('{recent_content['.$count_recent.']}',$content,$template);
			$template = str_replace('{recent_img['.$count_recent.']}',$content_img,$template);
			$template = str_replace('{recent_price['.$count_recent.']}',$column_recent[6],$template);
			$count_recent++;
		if ($count_recent > 3 || $count_recent > count($row_recent)) {break;}
	}
}
	if ($status_recent != 'OK') {
		$status_recent = $error_recent;
	}

?>