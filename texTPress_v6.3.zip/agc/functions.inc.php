<?php
// (c)2012 Flat File Database System by Muhammad Fauzan Sholihin 		www.tetuku.com		Paypal donation: tecnixindo@gmail.com		LR donation: U1462159 (Iyin payment gateway)		Indpnesian Bank : BCA 0372344006 SwiftCode=CENA IDJA
// Your donation will keep development process of this web apps. Thanks for your kindness
// You may use, modify, redistribute my apps for free as long as keep the origin copywrite
?>