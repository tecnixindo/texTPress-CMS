<?php

if (stristr($template,'{random')) { 
	$ar_random = explode("{random_content",$template);
			$row_random =  array_randsort(read_db('files/profil-dokter.txt',1,999));
//			$row_random =  array_randsort($row_global);
			foreach ($row_random as $column_random) {
				$random_detil['profil-dokter'] = $column_random;
//				$random_detil[$column_random[2]] = $column_random;
			}

	$random_no = 0;
	foreach ($ar_random as $random) {
		if ($random_no > 0) {
			$nama_random = in_string('_','}',$random);				
			$template = str_replace('{random_date_'.$nama_random.'}',date('d M Y - H:i',strtotime($random_detil[$nama_random][5])),$template);
			$template = str_replace('{random_title_'.$nama_random.'}',$random_detil[$nama_random][3],$template);
			$random_image = in_string('src="','"',$random_detil[$nama_random][4]);
			if ($content_image == '') {$random_image = $abs_url."images/no_image.png";}
//			$random_content = substr(stripslashes($random_detil[$nama_random][4]),0,125);
			$random_content = substr(stripslashes(strip_tags($random_detil[$nama_random][4],'<p><br>')),0,100)."...";
//			if (stristr($random_detil[$nama_random][8],'Summarized')) {$random_content = cuplik($random_content,555);}
			if (stristr($random_content,'[...]') ) {$random_content = str_replace('[...]','',$random_content);  }
			if ($random_detil[$nama_random][4] == '') {$random_content = '<h3>'.ucfirst(str_replace('-',' ',$nama_random)).'</h3>';}
			if ($random_detil[$nama_random][4] == '') {$random_content .= $error_random."<br>";}
			if ($_COOKIE['username'] != '') {$random_content = $random_content.' <a href="'.$abs_url.$random_detil[$nama_random][1].'/edit"><span class="glyphicon glyphicon-edit"></span> Edit</a>';}
			$template = str_replace('{random_content_'.$nama_random.'}',$random_content,$template);
			$template = str_replace('{random_img_'.$nama_random.'}',$random_image,$template);
			$template = str_replace('{random_permalink_'.$nama_random.'}',$abs_url.$nama_random.'/'.$random_detil[$nama_random][1],$template);
			}
		$random_no++;
	}
}

?>