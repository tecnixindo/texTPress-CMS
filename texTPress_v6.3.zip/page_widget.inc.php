<?php

if (stristr($template,'{widget')) {
	$ar_widget = explode("{widget_content",$template);
//			$row_widget = read_db('files/widget.txt',1,100);
			foreach ($row_widget as $column_widget) {
				$widget_detil[$column_widget[1]] = $column_widget;
			}
	$widget_no = 0;
	foreach ($ar_widget as $widget) {
		if ($widget_no > 0) {
			$nama_widget = in_string('_','}',$widget);				
			$template = str_replace('{widget_date_'.$nama_widget.'}',date('d M Y - H:i',strtotime($widget_detil[$nama_widget][5])),$template);
			$template = str_replace('{widget_title_'.$nama_widget.'}',$widget_detil[$nama_widget][3],$template);
			$content_image = in_string('src="','"',$widget_detil[$nama_widget][$i][4]);
			if ($content_image == '') {$content_image = $abs_url."images/no_image.png";}
			$widget_content = stripslashes($widget_detil[$nama_widget][4]);
			if (stristr($widget_detil[$nama_widget][8],'Summarized')) {$widget_content = cuplik($widget_content,555);}
			if (stristr($widget_content,'[...]') ) {$widget_content = str_replace('[...]','',$widget_content);  }
			if ($widget_detil[$nama_widget][4] == '') {$widget_content = '<h3>'.ucfirst(str_replace('-',' ',$nama_widget)).'</h3>';}
			if ($widget_detil[$nama_widget][4] == '') {$widget_content .= $error_widget."<br>";}
			if ($_COOKIE['username'] != '') {$widget_content = $widget_content.' <a href="'.$abs_url.'widget/'.$nama_widget.'/edit"><span class="glyphicon glyphicon-edit"></span> Edit</a>';}
			$template = str_replace('{widget_content_'.$nama_widget.'}',$widget_content,$template);
			$template = str_replace('{'.$page_type.'_img['.$i.']}',$content_image,$template);
			$template = str_replace('{widget_permalink_'.$nama_widget.'}',$abs_url.'widget/'.$widget_detil[$nama_widget][1],$template);
			}
		$widget_no++;
	}
}

?>