<!doctype html>
<html>
<head>
<meta charset="utf-8"><title>{meta_title}</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keyword}" />
	<meta name="author" content="{meta_author}" />

	<meta name="robots" content="INDEX,NOFOLLOW" />

	<meta property="og:image" content="{meta_ogg_image}" />
	<meta property="og:url" content="{meta_ogg_url" />
	<meta property="og:site_name" content="{meta_site_name}" />

<link rel="icon" href="{meta_favicon}" type="image/x-icon" />
<link rel="shortcut icon" href="{meta_favicon}" type="image/x-icon" />

<link rel="alternate" type="application/atom+xml" title="{meta_author} &raquo; Atom feed" href="{abs_url}atom/" />
<link rel="alternate" type="application/rss+xml" title="{meta_author} &raquo; RSS Feed" href="{abs_url}rss/" />
<link rel="alternate" type="application/rss+xml" title="{meta_author} &raquo; AGC Feed" href="{abs_url}agc/" />

    <link href="{abs_url}css/bootstrap.css" rel="stylesheet">
    {css_multi_color}
</head>

<body>
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <h1><a href="{abs_url}" class="navbar-brand">{meta_author}</a></h1>
			</div>
			<div class="navbar-collapse collapse navbar-right">
			  <div class="navbar-collapse collapse navbar-right">
			    <ul class="nav navbar-nav">
			      <li><a href="{abs_url}">Home</a></li>
			      <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">News<b class="caret"></b></a>
			        <ul class="dropdown-menu">
			          <li><a href="{abs_url}politic">Politic</a></li>
			          <li><a href="{abs_url}economy">Economy</a></li>
			          <li><a href="{abs_url}technology">Technology</a></li>
			          <li class="divider"></li>
			          <li class="dropdown-header">Entertainment</li>
			          <li><a href="{abs_url}celebrity">Celebrity</a></li>
			          <li><a href="{abs_url}hot-movie">Hot Movie</a></li>
		            </ul>
		          </li>
			      <li><a href="{abs_url}blog">Blog</a></li>
			    </ul>
{admin_panel}
		      </div>
			</div><!--/.navbar-collapse -->
      </div>
</div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<div class="container">
		  <div class="row">
				<div class="col-md-3">
    
                          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                          </button>
						<div class="navbar-collapse collapse">	
                            <p>&nbsp;</p>
                            <h3>{text_new}:</h3>
<!--start new-->
                            <p><a href="{new_permalink[]}">{new_title[]}</a>}</p>
<!--end new-->
                            <p>&nbsp;</p>
                            <h3>{text_popular}:</h3>
<!--start popular-->
                            <p><a href="{popular_permalink[]}">{popular_title[]}</a></p>
<!--end popular-->
                            <p>&nbsp;</p>
                            <h3>{text_recent}:</h3>
<!--start recent-->
                            <p><a href="{recent_permalink[]}">{recent_title[]}</a></p>
<!--end recent-->
                            <p>&nbsp;</p>
						</div>
				</div>
				<div class="col-md-9">
<!--start content-->
				  <h2>{content_title}</h2>
                  <small>{content_date}</small>
				  <p>&nbsp;</p>
                  {content}
                  <p>&nbsp;</p>
                  <h3>{text_related}:</h3>
<!--start related-->
                  <p><a href="{related_permalink[]}">{related_title[]}</a></p>
<!--end related-->
                  <p>&nbsp;</p>
<!--end content-->
			</div>
		  </div>
</div><!--/.container--> 
<p>&nbsp;</p>
    <div id="footer">
      <div class="container panel-footer">
        <div class="col-md-6 text-muted">&copy;2014 by <a href="{abs_url}" class="text-muted">{meta_author}</a>.</div>
        <div class="col-md-6 text-right text-muted"><a href="{abs_url}halaman/term-of-use" class="text-muted">Term of Use</a> | <a href="{abs_url}halaman/privacy-policy" class="text-muted">Privacy Policy</a><br />
          <a href="{abs_url}textpress/home" class="text-muted">texTPress v6.1</a>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
<!--script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script-->
<script src="{abs_url}js/jquery.js"></script>
<script src="{abs_url}js/bootstrap.js"></script>
<script src="{abs_url}js/masonry.min.js"></script>
</body>
</html>
