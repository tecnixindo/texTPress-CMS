<?php
include_once "../functions.inc.php";

$row_data = read_db('../files/setting.txt',1,999);
if ($row_data) {
	foreach ($row_data as $column_data => $value) {
		$setting[$value[1]] = $value;
	}
}

echo '<?xml version="1.0" ?>';
?>

<feed xmlns="http://www.w3.org/2005/Atom" xml:lang="en-us" xml:base="<?=$abs_url?>">
	<id><?=$abs_url?></id>
	<title><?=$setting[SiteConfig][2]?></title>
	<updated><?=date('Y-m-d')?>T<?=date('H:i:s')?>+00:00</updated>

	<link rel="self" href="/atom"><?=$abs_url?></link>
	<link href="/"><?=$abs_url?></link>
	<author>
		<name><? echo $setting[Meta][2];?></name>
		<uri><?=$abs_url?></uri>
	</author>
	<icon><?=$abs_url?>images/favicon.png</icon>
	<logo><?=$abs_url?>images/favicon.png</logo>
<?php
$row_data = read_db('../files/content_stats.txt',1,20);
foreach ($row_data as $column_data) {
	if (strlen($column_data[5]) >= 5) {
?>
	<entry>
		<link href="<?php echo $abs_url."/".$column_data[2]."/".$column_data[1];?>"></link>
		<title><?php echo $column_data[3];?></title>
		<published><?php echo date('l, d F Y H:i:s',strtotime($column_data[5]));?> -0400</published>
		<updated><?php echo date('l, d F Y H:i:s',strtotime($column_data[6]));?> -0400</updated>
		<content type="xhtml">
			<div xmlns="http://www.w3.org/1999/xhtml">
			<?php echo substr(strip_tags($column_data[4]),0,320);?>
			</div>
		</content>
	</entry>
<?php
	}
}
?>
</feed>
<!-- text-press.googlecode.com -->