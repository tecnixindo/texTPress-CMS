<?php include_once "ijin_user.inc.php";?>
<?php
include_once "functions.inc.php";

	if (file_exists('files/'.$path[0].'.txt')) {
		$content_key = get_key_db('files/'.$path[0].'.txt', $path[1]);
		$content_detil = key_db('files/'.$path[0].'.txt',$content_key);
	$recent_key = get_key_db('files/content_stats.txt', $path[1]);
	$recent_detil = key_db('files/content_stats.txt',$recent_key);


	del_db ('files/'.$path[0].'.txt',$content_detil[0]);
	del_db ('files/content_stats.txt',$recent_detil[0]);
	redirect($abs_url.$path[0],0.1);

	}

?>