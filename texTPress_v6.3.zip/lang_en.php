<?php
// English language
$btn_add = "Add";
$btn_edit = "Edit";
$btn_del = "Delete";
$btn_send = "Send";
$btn_send_comment = "Send comment";
$btn_save = "Save";
$btn_choice = "Your choice:";
$btn_activate = "Activate";

$first = "Firts";
$prev = "Previous";
$next = "Next";
$last = "Last";

$comment_name = "Your name";
$comment_identity = "Email or URL";
$comment_message = "Your message";

$administration = "Administration of";
$text_date = "Date";
$text_title = "Title";
$text_content = "Content";
$text_summary = "Summarize at first paragraph";
$text_price = "Price";
$text_content_note = "Note";
$text_content_note_info = "Note only visible by Admin when editing";
$text_activate = "Input activation code for ".$domain[host];
$text_activation_note = "You can copy paste the license code to create website at subdomain";


$post = "Post (show in public)";
$draft = "Draft (hidden)";

$title_site_setting = "Site setting";

$text_administration = "Administration";
$text_comment = "Comments";
$text_more = "Read more";

$text_related = "Related";
$text_new = "New";
$text_recent = "Recent";
$text_popular = "Popular";

$text_search = "Search";
$text_subscribe = "Subscribe";
$text_category = "Page category";

$text_signup = "Signup";
$text_login = "Login";
$text_lost_password = "Lost password";
$text_change_password = "Change password";
$text_your_email = "Your email";
$text_please = "Please";
$text_remember = "Remember me";
$text_lost_password_question = "Do you forget your password?";
$text_please_reset = "Please reset your password if you cannot login for many times";
$text_reset_note = "<p>After doing reset password, open your email to confirm that this reset password request is actually from you</p>
                <p>If you cannot found email at inbox, try to check email at spam box. Please click the \"not spam\" button to release message as not spam</p>";
$text_writable = "The folder is writable";
$text_not_writable = "The folder is not writable";
$text_textpress_contact = "Pin BB | 7CAEDDCC <br>WhatApp / Telegram | +6283840273173 <br>YM | cs.tetuku";

$text_tp_name = "Template name";
$text_tp_thumb = "Template thumbnail";
$text_tp_preview = "Live preview";
$text_tp_feature = "Template feature";
$text_tp_price = "Price";
$text_tp_owner = "Buy page url";

$error_related = "No related information yet";
$error_widget = "No data available";

$alert_logout = "You are logout";
$alert_must_login = "You must login to access this page";
$alert_login_fail = "Login failed ! \\nRecheck combination of email and password that you entered is correct";
$alert_email_not_registered = "Your email is not registered, please go to sign up form.\\nDo it now?";
$alert_save = "Data successfully saved";
$alert_sent = "Data successfully sent";
$alert_not_pass = "Data already exist, please check";
$alert_new_comment = "New comment at page";
$alert_not_textpress = "Is it template for texTPress? It seems not";
$alert_del = "Are you sure to delete?";

$text_email_contact = "Your contact message at website ";
?>