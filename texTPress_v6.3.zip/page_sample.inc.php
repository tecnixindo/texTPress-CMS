<?php
include_once "functions.inc.php";

$row_sample = read_db('files/sample_home.txt',1,99);

$row_sample_type = explode("<!--start ",$template);
foreach($row_sample_type as $column_sample_type) {
	$sample_type = in_string('','-->',$column_sample_type);
	if (strlen($sample_type) < 22) {
		if (!file_exists('files/'.$sample_type.'.txt')) {
			$row_sample = array_randsort($row_sample);
			$id = 0;
			foreach ($row_sample as $column_sample) {
					$id++;
					$column_sample[0] = $id;
					$column_sample[2] = $sample_type;
					$home_list[$sample_type][] = $column_sample;
			}
		}
	}
}
//print_r($sample_list);
//die();
?>