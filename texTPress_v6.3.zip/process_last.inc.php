<?php

include "pingpong.php";

if ($_POST['form_type'] == 'contact') {include "email_contact.inc.php";}

?>