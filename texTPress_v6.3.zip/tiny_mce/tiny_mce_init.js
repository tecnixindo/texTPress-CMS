// Uncomment and change this document.domain value if you are loading the script cross subdomains
document.domain = 'www.tetuku.com';	
// document_base_url : "http://www.tetuku.com/tiny_mce/"

tinyMCE.init({

	
		// General options
		// All textarea
		//mode : "textareas",
		
		// Specific textarea
		mode : "exact",
		elements : "deskripsi,content", // just pass the ID's of your textarea for which you want to add the editor
 
		theme : "advanced",
		plugins : "contextmenu,style,table,advhr,advimage,media,advlink,visualchars,nonbreaking,fullscreen",

		// Theme options
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,sub,sup,|,justifyleft,justifycenter,justifyright,justifyfull,|,link,unlink",
		theme_advanced_buttons2 : "bullist,numlist,|,outdent,indent,|,advhr,charmap,nonbreaking,|,image,media,|,table,cleanup,code,undo,redo,fullscreen",
		theme_advanced_buttons3 : "",
		theme_advanced_buttons4 : "",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "center",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,


		// Replace values for the template plugin
		template_replace_values : {
			username : "Tecnixindo Inter Media",
			staffid : "123456"
		}
	});
