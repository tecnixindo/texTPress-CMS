<? session_start();?>
 function drive (field_name, url, type, win) {

    /* If you work with sessions in PHP and your client doesn't accept cookies you might need to carry
       the session name and session ID in the request string (can look like this: "?PHPSESSID=88p0n70s9dsknra96qhuk6etm5").
       These lines of code extract the necessary parameters and add them back to the filebrowser URL again. */

    var cmsURL = "http://drive1.tetuku.com/embed.php?group=<? echo $_SESSION['username'];?>";    // script URL - use an absolute path!
//    var cmsURL = "http://localhost/";    // script URL - use an absolute path!if (cmsURL.indexOf("?") < 0) {
        //add the type as the only query parameter
        cmsURL = cmsURL + "?type=" + type;
    }
    else {
        //add the type as an additional query parameter
        // (PHP session ID is now included if there is one at all)
        cmsURL = cmsURL + "&type=" + type;
    }

    tinyMCE.activeEditor.windowManager.open({
        file : cmsURL,
        title : 'Drive Plugin',
        width : 800, 
        height : 500,
        resizable : "yes",
		  scrollbars : "yes",
        inline : "yes",  // This parameter only has an effect if you use the inlinepopups plugin!
        close_previous : "no"
    }, {
        window : winpopup,
        input : field_name
    });
    return false;
  }

	function selectURL(url)
	{
		document.passform.fileurl.value = url;
		FileBrowserDialogue.mySubmit();
	}
	var FileBrowserDialogue = {
	    init : function () {
	        // Here goes your code for setting your custom things onLoad.
				rowHighlight();
	    },
	    mySubmit : function () {
	 		  var URL = document.passform.fileurl.value;
	        var win = tinyMCEPopup.getWindowArg("window");
	
	        // insert information now
	        win.document.getElementById(tinyMCEPopup.getWindowArg("input")).value = URL;
	
	        // for image browsers: update image dimensions
			  if (typeof(win.ImageDialog) != "undefined" && document.URL.indexOf('type=image') != -1)
				  {
		        if (win.ImageDialog.getImageData) win.ImageDialog.getImageData();
		        if (win.ImageDialog.showPreviewImage) win.ImageDialog.showPreviewImage(URL);
				  }
	
	        // close popup window
	        tinyMCEPopup.close();
	    }
	}
	tinyMCEPopup.onInit.add(FileBrowserDialogue.init, FileBrowserDialogue);
