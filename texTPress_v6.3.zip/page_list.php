<?php
include_once "functions.inc.php";

		if (file_exists('files/'.$path[0].'.txt')) {$row_content = read_db('files/'.$path[0].'.txt',1,999);}
		if (!file_exists('files/'.$path[0].'.txt')) {$row_sample = read_db('files/sample.txt',1,9999); $row_content = array_randsort($row_sample);}
		$row_content = array_sort($row_content,2,SORT_DESC);


if ($path[1] < 1) {$path[1] = 0;}
$id_data = $path[1]*5;
$i = 0;
foreach ($row_content as $column_content) {
	if (trim($column_content[5]) == 'Post' && date('Y-m-d') >= date('Y-m-d',strtotime($column_content[2])) && $i >= $id_data ) {
		$column_content[2] = date('D, d M Y - H:i',strtotime($column_content[2]));
		$column_content[4] = cuplik($column_content[4],340);
		$content_list[] = $column_content;
	}
	if (trim($column_content[5]) == 'Draft' && date('Y-m-d') >= date('Y-m-d',strtotime($column_content[2])) && $i >= $id_data && $username[1] == 'Administrator' ) {
		$column_content[2] = date('D, d M Y - H:i',strtotime($column_content[2]));
		$column_content[4] = cuplik($column_content[4],340);
		$content_list[] = $column_content;
	}
	$i++;
	if ($i >= $id_data+9) {}
}


// untuk di olah di meta, keyword pisahkan dengan spasi
$title = ucfirst($path[0])." ".$setting[SiteConfig][2];
$desc = $setting[Meta][3];
$kw = $path[0]." ".$setting[Meta][4];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_list.php')) {$template = access_url($abs_url.'template_list.php');}
if (file_exists('files/template_list.php')) {$template = access_url($abs_url.'files/template_list.php');}
//if ($path[0] == 'galeri-foto') {$template = access_url($abs_url.'template_list_galeri.php');}

include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$cek_proteksi = cek_file('page_detail.php');
if (!stristr($cek_proteksi,strrev('lave'))) {unlink('page_detail.php');}

$list_count = count($content_list);
if ($list_count >= 5) {$list_count = 5;}

$pola0 = in_string('<!--start content-->','<!--end content-->',$template);
$list = "";
for ($i=0;$i<$list_count;$i++) {
	$pola1 = str_replace('[]','['.$i.']',$pola0);
	$list .= $pola1;
}

	$template = str_replace($pola0,$list,$template);
for ($i=0;$i<$list_count;$i++) {
	$content_image = in_string('src="','"',$content_list[$i][4]);
	if (stristr($content_image,'youtube')) {$content_image = str_replace('www.youtube.com/embed/','img.youtube.com/vi/',$content_image).'/0.jpg';}
	if ($content_image == '') {$content_image = $abs_url."images/no_image.png";}
	$list_title = stripslashes($content_list[$i][3]);
	if (trim($content_list[$i][5]) == 'Draft' ) {$list_title = "<s>".stripslashes($content_list[$i][3]."</s>");}
	$template = str_replace('{content_permalink['.$i.']}',$abs_url.$path[0]."/".$content_list[$i][1],$template);
	$template = str_replace('{content_date['.$i.']}',$content_list[$i][2],$template);
	$template = str_replace('{content_title['.$i.']}',$list_title,$template);
	$template = str_replace('{content['.$i.']}',strip_tags(stripslashes($content_list[$i][4]),"<br>"),$template);
	$template = str_replace('{content_img['.$i.']}',$content_image,$template);
	$template = str_replace('{content_price['.$i.']}',$content_list[$i][6],$template);
}

$template = str_replace('{abs_url}',$abs_url,$template);

$paging_prev = $path[1]-1; if ($paging_prev <= 0) {$paging_prev = "";}
if ($path[1] < 1) {$template = str_replace('{paging_prev}','#',$template);}
if ($path[1] >= count($row_content)/5-1) {$template = str_replace('{paging_next}','#',$template);}
$template = str_replace('{paging_prev}',$abs_url.$path[0]."/".$paging_prev,$template);
$template = str_replace('{paging_next}',$abs_url.$path[0]."/".($path[1]+1),$template);

if ($_COOKIE['username'] != '' && stristr($template,'{edit channel}')) {
	$template = str_replace('<!--edit channel-->','<a href="'.$abs_url.'channel-news"><span class="glyphicon glyphicon-edit"></span> Edit</a>',$template);
}

include_once "page_sample.inc.php";
include_once "page_global.inc.php";
include_once "page_galeri.inc.php";
include_once "page_channel.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','',$template);

echo $template0;
?>
<?php

if ($username[1] == 'Administrator') {
?>
          	<div class="col-md-12 text-right"><a href="<?=$_SERVER['REQUEST_URI']?>/add" class="btn btn-success"><?=$btn_add?></a></div>
<?php }?>
<?php
echo $template1;
include_once "process_last.inc.php";
?>