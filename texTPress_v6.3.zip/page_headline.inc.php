<?php
include_once "functions.inc.php";
//setting headline
$headline_total = 1;

		$row_headline = $row_global;
		$row_headline = array_sort($row_headline,5,SORT_DESC);
		
		foreach ($row_headline as $column_headline) {
			$column_headline[5] = date('d M Y',strtotime($column_headline[5]));
		}

$count_headline = 0;
foreach ($row_headline as $column_headline) {
	if (strlen($column_headline[3]) > 11 && !stristr($column_headline[1],$path[1])) {
			$content_img = in_string('img src="','"',$column_headline[4]);
			if ($content_img == '') {$content_img = $abs_url."images/no_image.png";}
			$template = str_replace('{headline_permalink['.$count_headline.']}',$abs_url.$column_headline[2].'/'.$column_headline[1],$template);
			$template = str_replace('{headline_date['.$count_headline.']}',$column_headline[5],$template);
			$template = str_replace('{headline_title['.$count_headline.']}',stripslashes($column_headline[3]),$template);
			$template = str_replace('{headline_content['.$count_headline.']}',strip_tags(stripslashes($column_headline[4])),$template);
			$template = str_replace('{headline_img['.$count_headline.']}',$content_img,$template);
			$template = str_replace('{headline_price['.$count_headline.']}',$column_headline[6],$template);
			$count_headline++;
		if ($count_headline > $headline_total || $count_headline > count($row_headline)) {break;}
	}
}
	if ($status_headline != 'OK') {
		$status_headline = $error_headline;
	}

?>