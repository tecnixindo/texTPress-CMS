<?php
include_once "functions.inc.php";

		$row_popular = $row_global;
		if (!file_exists('files/'.$path[0].'.txt') && $path[0] != '') {$row_popular = read_db('files/sample_home.txt',1,99);}
		$row_popular = array_sort($row_popular,7,SORT_DESC);

		foreach ($row_popular as $column_popular) {
			$column_popular[5] = date('d M Y',strtotime($column_popular[5]));
		}

	$pola0 = in_string('<!--start popular-->','<!--end popular-->',$template);
	$list = "";
$count_popular = 0;
	for ($i=0;$i<count($row_popular);$i++) {
		$pola1 = str_replace('[]','['.$i.']',$pola0);
		$list .= $pola1;
		if ($i >= 3 || $i >= count($row_popular)) {break;}
	}
		$template = str_replace($pola0,$list,$template);


$count_popular = 0;
foreach ($row_popular as $column_popular) {
	if (strlen($column_popular[3]) > 11 && !preg_match('/galeri|widget|halaman/i',$column_popular[2]) && !stristr($column_popular[1],$path[1]) && !stristr($column_popular[1],$popular_inserted) && date('Y-m-d',strtotime($column_popular[5])) >= date('Y-m-d',mktime(0, 0, 0, date('m'), date('d')-10, date('Y'))) ) {
			$content_img = in_string('img src="','"',$column_popular[4]);
			if ($content_img == '') {$content_img = $abs_url."images/no_image.png";}
			$content = substr(strip_tags(stripslashes($column_popular[4]),"<br>"),0,120)."...";
			$template = str_replace('{popular_permalink['.$count_popular.']}',$abs_url.$column_popular[2].'/'.$column_popular[1],$template);
			$template = str_replace('{popular_date['.$count_popular.']}',$column_popular[5],$template);
			$template = str_replace('{popular_title['.$count_popular.']}',stripslashes($column_popular[3]),$template);
			$template = str_replace('{popular_content['.$count_popular.']}',$content,$template);
			$template = str_replace('{popular_img['.$count_popular.']}',$content_img,$template);
			$template = str_replace('{popular_price['.$count_popular.']}',$column_popular[6],$template);
			$count_popular++;
			$popular_inserted .= $column_popular[1];
		if ($count_popular > 3 || $count_popular > count($row_popular)) {break;}
	}
}
	if ($status_popular != 'OK') {
		$status_popular = $error_popular;
	}

?>