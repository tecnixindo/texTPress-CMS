<!doctype html>
<html>
<head>
	<title>{meta_title}</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keyword}" />
	<meta name="author" content="{meta_author}" />

	<meta name="robots" content="INDEX,FOLLOW" />
	<meta name="robots" content="noimageindex" />	

	<meta property="og:image" content="{meta_ogg_image}" />
	<meta property="og:url" content="{meta_ogg_url}" />
	<meta property="og:site_name" content="{meta_site_name}" />

<link rel="icon" href="{meta_favicon}" type="image/x-icon" />
<link rel="shortcut icon" href="{meta_favicon}" type="image/x-icon" />

<link rel="alternate" type="application/atom+xml" title="{meta_author} &raquo; Atom feed" href="{abs_url}atom/" />
<link rel="alternate" type="application/rss+xml" title="{meta_author} &raquo; RSS Feed" href="{abs_url}rss/" />
<link rel="alternate" type="application/rss+xml" title="{meta_author} &raquo; AGC Feed" href="{abs_url}agc/" />

    <link href="css/bootstrap.css" rel="stylesheet">
    {css_multi_color}
</head>

<body>
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
		<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <h1><a href="{abs_url}" class="navbar-brand">{meta_author}</a></h1>
			</div>
			<div class="navbar-collapse collapse navbar-right">
			  <ul class="nav navbar-nav">
			    <li><a href="{abs_url}">Home</a></li>
			    <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">News<b class="caret"></b></a>
			      <ul class="dropdown-menu">
			        <li><a href="{abs_url}politic">Politic</a></li>
			        <li><a href="{abs_url}economy">Economy</a></li>
			        <li><a href="{abs_url}technology">Technology</a></li>
			        <li class="divider"></li>
			        <li class="dropdown-header">Entertainment</li>
			        <li><a href="{abs_url}celebrity">Celebrity</a></li>
			        <li><a href="{abs_url}hot-movie">Hot Movie</a></li>
		          </ul>
		        </li>
			    <li><a href="{abs_url}blog">Blog</a></li>
			  </ul>
{admin_panel}
	    </div>
			<!--/.navbar-collapse -->
      </div>
</div>
<div class="container">
        <div class="jumbotron">
			<h1>{widget_title_tentang-textpress-cms}</h1>
			<p>{widget_content_tentang-textpress-cms}</p>
			<p><a href="{widget_permalink_tentang-textpress-cms}" class="btn btn-primary btn-lg" role="button">{text_more} &raquo;</a></p>
            
		</div>
		<div class="row">
			<div class="col-md-4">
			  <h2>{widget_title_kecepatan-textpress-cms}</h2>
			  <p>{widget_content_kecepatan-textpress-cms} </p>
			  <p><a href="{widget_permalink_kecepatan-textpress-cms}" class="btn btn-info" role="button">{text_more} &raquo;</a></p>
			</div>
			<div class="col-md-4">
			  <h2>{widget_title_kemudahan-textpress-cms}</h2>
              <p>{widget_content_kemudahan-textpress-cms} </p>
              <p><a href="{widget_permalink_kemudahan-textpress-cms}" class="btn btn-info" role="button">{text_more} &raquo;</a></p>
           </div>
			<div class="col-md-4">
			  <h2>{widget_title_kehandalan-textpress-cms}</h2>
              <p>{widget_content_kehandalan-textpress-cms} </p>
              <p><a href="{widget_permalink_kehandalan-textpress-cms" class="btn btn-info" role="button">{text_more} &raquo;</a></p>
			</div>
		</div>
        <p>&nbsp;</p>
        <div class="row">
        	<div class="col-md-3">
            <h3>Politic</h3>
<!--start politic-->
				  <strong>{politic_title[]}</strong><br>
				  <small>{politic_date[]}</small><br><br>
				  <span class="col-md-12"><img src="{politic_img[]}"  alt="" class="img img-responsive" /></span>{politic_content[]}
<p><a href="{politic_permalink[]}" class="btn btn-default">{text_more} &raquo;</a></p>
				  <p>&nbsp;</p>
<!--end politic-->
            </div>
        	<div class="col-md-3">
            <h3>Hot Movie</h3>
<!--start hot-movie-->
				  <strong>{hot-movie_title[]}</strong><br>
				  <small>{hot-movie_date[]}</small><br><br>
				  <span class="col-md-12"><img src="{hot-movie_img[]}"  alt="" class="img img-responsive" /></span>{hot-movie_content[]}
<p><a href="{hot-movie_permalink[]}" class="btn btn-default">{text_more} &raquo;</a></p>
				  <p>&nbsp;</p>
<!--end hot-movie-->
            </div>
        	<div class="col-md-3">
            <h3>Technology</h3>
<!--start technology-->
				  <strong>{technology_title[]}</strong><br>
				  <small>{technology_date[]}</small><br><br>
				  <span class="col-md-12"><img src="{technology_img[]}"  alt="" class="img img-responsive" /></span>{technology_content[]}
<p><a href="{technology_permalink[]}" class="btn btn-default">{text_more} &raquo;</a></p>
				  <p>&nbsp;</p>
<!--end technology-->
            </div>
        	<div class="col-md-3">
            <h3>Celebrity</h3>
<!--start celebrity-->
				  <strong>{celebrity_title[]}</strong><br>
				  <small>{celebrity_date[]}</small><br><br>
				  <span class="col-md-12"><img src="{celebrity_img[]}"  alt="" class="img img-responsive" /></span>{celebrity_content[]}
<p><a href="{celebrity_permalink[]}" class="btn btn-default">{text_more} &raquo;</a></p>
				  <p>&nbsp;</p>
<!--end celebrity-->
            </div>
        </div>
        <p>&nbsp;</p>
</div><!--/.container-->
    <div id="footer">
      <div class="container panel-footer">
        <div class="col-md-6 text-muted">&copy;2014 by <a href="{abs_url}" class="text-muted">{meta_author}</a>.</div>
        <div class="col-md-6 text-right text-muted"><a href="{abs_url}halaman/term-of-use" class="text-muted">Term of Use</a> | <a href="{abs_url}halaman/privacy-policy" class="text-muted">Privacy Policy</a><br />
          <a href="{abs_url}textpress/home" class="text-muted">texTPress v6.1</a> </div>
      </div>
    </div>

<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
<!--script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script-->
<script src="{abs_url}js/jquery.js"></script>
<script src="{abs_url}js/bootstrap.js"></script>
<script src="{abs_url}js/masonry.min.js"></script>
</body>
</html>
