
<style type="text/css">
.sorot div:hover {
	background-color:#bce8f1;
}

.img-left{
	margin: 12px;
	padding: 6px;
	float: left;
	clear: none;
	border: thin solid #CCCCCC;
}
</style>
