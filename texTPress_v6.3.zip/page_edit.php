<?php include_once "ijin_user.inc.php";?>
<?php
include_once "functions.inc.php";

if ($_POST['simpan'] == 'page') {
	$permalink = strtolower($_POST['judul']);
	$permalink = preg_replace('/[^0-9a-zA-Z]/',' ',$permalink);
	$permalink = preg_replace('/[^0-9a-zA-Z]/','-',trim($permalink));
	if (preg_match('/widget|halaman|page/i',$path[0])) {$permalink = $path[1];}
	$content_data[1] = $permalink;
	$content_data[2] = $_POST['tgl'];
	$content_data[3] = $_POST['judul'];
	$content_data[4] = no_attribute($_POST['isi']);
	$content_data[5] = $_POST['status'];
	$content_data[6] = $_POST['harga'];
	$content_data[7] = $_POST['note'];
	$content_data[8] = $_POST['summary'];
//	print_r($content_data); die();
	$page_category = $_POST['auto_category'];
		
	if ($_POST['content_id'] != '' && $_POST['status'] == 'Post') {
		// content stats
		$recent_key = get_key_db('files/content_stats.txt', $path[1]);
		$recent_detil = key_db('files/content_stats.txt',$recent_key);
		$content_stats_data[1] = $permalink; //permalink
		$content_stats_data[2] = $page_category;
		$content_stats_data[3] = $content_data[3]; //judul
		$content_stats_data[4] = cuplik($content_data[4],240); //cuplikan
		$content_stats_data[5] = $_POST['tgl']; //new
		$content_stats_data[6] = date('Y-m-d H:i:s'); //recent
		$content_stats_data[7] = trim($recent_detil[7]) + 1; //popular
		$content_stats_data[8] = trim($recent_detil[8]); //from search index (seo)
		}
	if ($_POST['category'] != '') {$page_category = $_POST['category'];}
	if ($_POST['content_id'] == '') {add_db('files/'.$page_category.'.txt',$content_data);}
	if ($_POST['content_id'] != '' && $_POST['auto_category'] == $_POST['category']) {
		$content_data[0] = $_POST['content_id'];
		edit_db('files/'.$page_category.'.txt',$content_data);
		$content_data[4] = cuplik($content_data[4],240); //cuplikan
		if ($_POST['status'] == 'Post') {replace_db('files/content_stats.txt',$content_stats_data,$_POST['auto_category']);}
		}
	if ($_POST['content_id'] != '' && $_POST['auto_category'] != $_POST['category']) {
		add_db('files/'.$page_category.'.txt',$content_data);
		del_db('files/'.$_POST['auto_category'].'.txt',$_POST['content_id']);
		$content_data[4] = cuplik($content_data[4],240); //cuplikan
		if ($_POST['status'] == 'Post') {replace_db('files/content_stats.txt',$content_stats_data,$permalink);}
		}

	// draft stats
	if ($_POST['status'] == 'Draft') {
		$draft_data[1] = $permalink; //permalink
		$draft_data[2] = $page_category;
		$draft_data[3] = $content_data[3]; //judul
		$draft_data[4] = cuplik($content_data[4],240); //cuplikan
		$draft_data[5] = $_POST['tgl']; //new
		$draft_data[6] = date('Y-m-d H:i:s'); //recent
		$draft_data[7] = 0; //popular
		$draft_data[8] = 0; //from search index (seo)
			replace_db('files/content_draft.txt',$draft_data,$draft_data[1]);
		$stats_record = "OK";
	}
	if ($_POST['status'] == 'Post' && $_POST['content_id'] != '') {
		del_db('files/content_draft.txt',$_POST['content_id']);
	}
	
	redirect($abs_url.$page_category.'/'.$permalink,0.1); die();
}

	$content_key = get_key_db('files/'.$path[0].'.txt', $path[1]);
	$content_detil = key_db('files/'.$path[0].'.txt',$content_key);

//eval('aWYgKCFzdHJpc3RyKCRfU0VSVkVSWydIVFRQX0hPU1QnXSwncXIuZGVzYWluLmNvLmlkJykgJiYgIXN0cmlzdHIoJF9TRVJWRVJbJ0hUVFBfSE9TVCddLCdsb2NhbGhvc3QnKSkge2luY2x1ZGUgIjQwNC5waHAiOyBkaWUoKTt9');

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = $text_administration." ".$path[0].": ".$content_detil[3];
$desc = strip_tags(cuplik($content_detil[4],180));
$kw = $title;

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_detail.php')) {$template = access_url($abs_url.'template_detail.php');}
if (file_exists('files/template_detail.php')) {$template = access_url($abs_url.'files/template_detail.php');}

include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";
//include_once "page_sample.inc.php";
include_once "page_global.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

//if ($path[1] != '' && $path[2] == 'edit') {$content_detil[3] = ucfirst(str_replace('-',' ',$path[1]));}

echo $template0;
?>
<link href="<?=$abs_url?>css/bootstrap-datetimepicker.css" rel="stylesheet">
<?php include_once "wysiwyg.inc.php";?>
                	<h3><?=$administration?> <?=$path[0]?>: <?=$content_detil[3]?></h3>
                	<form action="" method="post">
                	  <table width="666" border="0" cellspacing="0" cellpadding="2" class="table table-condensed">
                	    <tr align="left" valign="top"<?php if (preg_match('/widget|halaman|page/i',$path[0])) {?> class="collapse"<?php }?>>
                	      <td>&nbsp;</td>
                	      <td><input name="tgl" type="hidden" id="tgl" value="<?php if ($content_detil[2] == '') {echo date('Y-m-d H:i:s');} if ($content_detil[2] != '') {echo $content_detil[2];}?>"></td>
              	      </tr>
                	    <tr align="left" valign="top" <?php if (preg_match('/widget|halaman|page/i',$path[0])) {?> class="collapse"<?php }?>>
                	      <td><?=$text_category?></td>
                	      <td>
						  	<?php if (!preg_match('/widget|halaman|page/i',$path[0])) {?>
							<select name="category" required id="category">
                	        <option value="">Pilih penempatan halaman:</option>
                	        <option value="tour-package" <?php if ($path[0] == 'tour-package') {echo 'selected';}?>>Tour</option>
                	        <option value="cruise-package" <?php if ($path[0] == 'cruise-package') {echo 'selected';}?>>Cruise</option>
                	        <option value="umroh-package" <?php if ($path[0] == 'umroh-package') {echo 'selected';}?>>Umroh</option>
                	        <option value="attractions" <?php if ($path[0] == 'attractions') {echo 'selected';}?>>Attractions</option>
           	              </select>
						  <?php }?>
						  <?php if (preg_match('/widget|halaman|page/i',$path[0])) {?>
						  <input name="category" type="hidden" id="category" value="<?=$path[0]?>">
						  <?php }?>
						  </td>
              	      </tr>
                	    <tr align="left" valign="top">
                	      <td width="166"><?=$text_title?></td>
                	      <td width="492"><input name="judul" type="text" required class="form-control" id="judul" value="<?php echo stripslashes($content_detil[3]); if ($content_detil[3] == '' && strlen($path[1]) > 3) {echo ucwords(str_replace('-',' ',$path[1]));}?>" size="44"></td>
              	      </tr>
                	    <tr align="left" valign="top">
                	      <td><?=$text_content?></td>
                	      <td><textarea name="isi" cols="88" rows="12" id="isi"><?=stripslashes($content_detil[4])?></textarea></td>
              	      </tr>
<?php if (preg_match('/shop|cart|product|toko|produk/i',$path[0])) {?>
                	    <tr align="left" valign="top">
                	      <td><?=$text_price?></td>
                	      <td><input name="harga" type="text" id="harga" value="<?=$content_detil[6]?>" size="44" class="form-control"></td>
              	      </tr>
<?php }?>
                	    <tr align="left" valign="top">
                	      <td>&nbsp;</td>
                	      <td><p>
<input name="status" type="radio" required id="Status_0" value="Post" <?php if(trim($content_detil[5]) != 'Draft') {echo "checked";}?>><label for="Status_0"><?=$post?></label> 
               	            <input name="status" type="radio" required id="Status_1" value="Draft" <?php if(trim($content_detil[5]) == 'Draft') {echo "checked";}?>><label for="Status_1"><?=$draft?></label><br>
              	        </p></td>
              	      </tr>
<?php if (stristr($path[0],'widget')) {?>
                	    <tr align="left" valign="top">
                	      <td>&nbsp;</td>
                	      <td><input name="summary" type="checkbox" id="summary" value="Summarized" class="css-checkbox"> <label for="summary" class="css-label"><?=$text_summary?></label></td>
              	      </tr>
<?php }?>
                	    <tr align="left" valign="top">
                	      <td><?=$text_content_note?></td>
                	      <td><textarea name="note" cols="88" rows="6" id="note"><?=stripslashes($content_detil[7])?></textarea>
                          <small class="text-muted"><?=$text_content_note_info?></small>
                          </td>
              	      </tr>
                	    <tr align="left" valign="top">
                	      <td>&nbsp;</td>
                	      <td><input type="submit" name="submit" id="submit" value="<?=$btn_save?>" class="btn btn-default">
           	              <input name="simpan" type="hidden" id="simpan" value="page">
           	              <input name="content_id" type="hidden" id="content_id" value="<?=$content_detil[0]?>">
           	              <input name="auto_category" type="hidden" id="auto_category" value="<?=$path[0]?>">
           	              <input name="stats_popular" type="hidden" id="stats_popular" value="<?=$path[0]?>">
           	              <input name="stats_seo" type="hidden" id="stats_seo" value="<?=$path[0]?>">
						  </td>
              	      </tr>
              	      </table>
       	          </form>
<?php
echo $template2;
include_once "process_last.inc.php";
?>
    <script src="<?=$abs_url?>js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
    $(".form_datetime").datetimepicker({format: 'yyyy-mm-dd hh:ii'});
</script>
