<?php
include_once "functions.inc.php";

   // kirim email
   $domain = $_SERVER['HTTP_HOST'];
   $domain = str_replace('/','',$domain);
   $domain = str_replace('www.','',$domain);
$cek_user = cek_file('files/user.txt');
$email_owner = in_string('{,}Administrator{,}','{,}',$cek_user);
       // save and send notification email
	   if ($lang == 'en') {$email_format = 'email_contact_en.html';}
	   if ($lang == 'id') {$email_format = 'email_contact_id.html';}
      $emailbody = read_file($email_format);
      $emailbody = str_replace("{contact_name}",$_POST['contact_name'],$emailbody);
      $emailbody = str_replace("{contact_message}",$_POST['contact_message'],$emailbody);
      $emailbody = str_replace("{contact_email}",$_POST['contact_email'],$emailbody);
      $emailbody = str_replace("{meta_author}",$setting[Meta][2],$emailbody);
	  if (strlen($setting[Meta][5] < 4)) {$emailbody = str_replace("{meta_favicon}",$abs_url.'files/'.trim($setting[Meta][5]),$emailbody);}
      $emailbody = str_replace("{meta_favicon}",$abs_url.'files/'.trim($setting[Meta][5]),$emailbody);
      $emailbody = str_replace("{ip_user}",$_SERVER['REMOTE_ADDR'],$emailbody);
      $emailbody = str_replace("{abs_url}",$domain[host],$emailbody);

$headers .= "From: ".$setting[Meta][2]." <'robot@".$domain[host]."'>\n";
$headers .= "X-Sender: <'robot@".$domain[host]."'>\n";
$headers .= "X-Mailer: PHP\n"; // mailer
$headers .= "X-Priority: 1\n"; // Urgent message!
$headers .= "Return-Path: <'cs@ora.keren.la'>\n";  // Return path for errors

// If you want to send html mail, uncomment the following line 
$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type

      mail($_POST['contact_email'], $text_email_contact." ".$domain[host], $emailbody, $headers);
      mail($email_owner, "Copy: ".$text_email_contact." ".$domain[host], $emailbody, $headers);

$pesan = $alert_sent;

//akhir kirim email	*/
?>