$(function() {
    // Code for docs warnas
    function createColorpickers() {
        // Api warna
        var bodyStyle = $('body')[0].style;
        $('#warna_apiwarna').colorpicker({
            color: bodyStyle.backgroundColor
        }).on('changeColor', function(ev) {
            bodyStyle.backgroundColor = ev.color.toHex();
        });

        // Horizontal mode
        $('#warna_forceformat').colorpicker({
            format: 'rgba', // force this format
            horizontal: true
        });

        $('.warna-auto').colorpicker();

        // Disabled / enabled triggers
        $(".disable-button").click(function(e) {
            e.preventDefault();
            $("#warna_endis").colorpicker('disable');
        });

        $(".enable-button").click(function(e) {
            e.preventDefault();
            $("#warna_endis").colorpicker('enable');
        });
    }

    createColorpickers();

    // Create / destroy instances
    $('.warna-destroy').click(function(e) {
        e.preventDefault();
        $('.warna').colorpicker('destroy');
        $(".disable-button, .enable-button").off('click');
    });

    $('.warna-create').click(function(e) {
        e.preventDefault();
        createColorpickers();
    });
});
