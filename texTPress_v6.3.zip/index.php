<?php
//texTPress CMS (c) Muhammad Fauzan Sholihin - tecnixindo@gmail.com - WA/Telegram/SMS | +62 838 402 73173 - BBM 7CAEDDCC
// Do not touch encrypted script. It may cause unexpected crash

include_once "functions.inc.php";
//error_reporting(0);

//demo dulu
/*
if ($path[0] != '' && $path[1] != '') {include_once "template_detail.htm"; die();}
if ($path[0] != '') {include_once "template_list.htm"; die();}
if ($path[0] == '') {include_once "template_home.htm"; die();}
*/

if ($_POST['cari'] != '') {	$search_data = strtolower($_POST['cari']); $search_data = preg_replace('/[^0-9a-zA-Z]/',' ',$search_data); $search_data = preg_replace('/[^0-9a-zA-Z]/','-',trim($search_data)); redirect($abs_url.'cari/'.$search_data);}
if ($_POST['search'] != '') {	$search_data = strtolower($_POST['search']); $search_data = preg_replace('/[^0-9a-zA-Z]/',' ',$search_data); $search_data = preg_replace('/[^0-9a-zA-Z]/','-',trim($search_data)); redirect($abs_url.'search/'.$search_data);}

if ($_COOKIE['username'] != '') {$username = unserialize(base64_decode($_COOKIE['username']));}

$row_data = read_db('files/setting.txt',1,99);
if ($row_data) {
	foreach ($row_data as $column_data => $value) {
		$setting[$value[1]] = $value;
	}
}

$row_global_raw = read_db('files/content_stats.txt',1,9999);
	foreach ($row_global_raw as $column_global) {
		if (!stristr($global_inserted,$column_global[1])) {$row_global[] = $column_global;}
		$global_inserted .= $column_global[1];
	}
$row_global_raw = "";
$global_inserted = "";
$row_widget = read_db('files/widget.txt',1,9999);

include_once "stats.inc.php";

$lang = "en";
include_once 'ip2country.inc.php';
$ip2c = new Ip2Country;
$ip2c->load($_SERVER['REMOTE_ADDR']);
if (stristr($ip2c->countryCode,'id') || stristr(getenv("HTTP_USER_AGENT"),'indonesia')) {$lang = "id";}
// if ($setting[SiteLanguage] != '') {$lang = $setting[SiteLanguage];}
if ($lang == 'id') {include_once "lang_id.php";}
if ($lang != 'id') {include_once "lang_en.php";}

if ($setting[SiteConfig] == '' && !stristr($path[0],'install')) {redirect('install'); die();}
if ($path[0] == 'install') {include_once "install.php"; die();}

if ($path[0] == '') {include_once "page_home.php"; die();}

//textpress page
if ($path[0] == 'textpress' && $path[1] == 'home') {include_once "tp_home.php"; die();}
if ($path[0] == 'textpress' && $path[1] == 'template') {include_once "tp_template.php"; die();}
if ($path[0] == 'textpress' && $path[1] == 'documentation') {include_once "tp_documentation.php"; die();}
if ($path[0] == 'textpress' && $path[1] == 'affiliate') {include_once "tp_affiliate.php"; die();}

//member area
if ($path[0] == 'login') {include_once "user_login.php"; die();}
if ($path[0] == 'lost-password') {include_once "user_login_lupa.php"; die();}
if ($path[0] == 'logout') {include "user_logout.php"; die();}

//member panel
if ($path[0] == 'panel') {
	if ($lang == 'en') {include "panel_home_en.php"; die();}
	if ($lang == 'id') {include "panel_home_id.php"; die();}	
	}
if ($path[0] == 'upgrade-textpress') {include "panel_upgrade.php"; die();}
if ($path[0] == 'copy-license') {include "panel_copy_license.php"; die();}
if ($path[0] == 'change-template') {include "panel_template.php"; die();}
if ($path[0] == 'meta-tags') {include "panel_meta_tags.php"; die();}
if ($path[0] == 'meta-tags') {include "panel_meta_tags.php"; die();}
if ($path[0] == 'change-password') {include "user_change_password.php"; die();}

eval(decrypt("YOa+vrUYT/jdE5PZqldzMrXbSt+aR6bQK+dg7vg3itXBnz52+patYbn8ysK3pLqpDKl8gvqeYiuLP/HvnJDs/3yjddJPh+zW4szDTLOpn6UqYm2NK45cTDuByBmVZB8Mr2fTU2sI+2pOIsoE4cUP5b3Nf5oodepVtM3cXDKCoJMP55qJgoUiCnbLaImUln7NtzPWiYL3t7uvT+rk3rrtdv0kZmlcGpV2U9aek9ZSIXZ9trSqmGG7IDBdPNqoSjxQoSKbcbBzmIQ6lBDXO9YAWccViH/v/rdQnOjaWmHNl/U="));


//halaman
if ($path[0] == 'berita-baru') {
	include_once "page_edit.php"; die();
}
if (preg_match('/halaman|page|widget/i',$path[0]) && $path[1] == '') {redirect($abs_url); die();}
if ($path[0] != '') {
	if ($path[1] == 'edit' || $path[1] == 'add') {include_once "page_edit.php"; die();}
	if ($path[1] == 'del') {include_once "page_del.php"; die();}
	if ($path[0] == 'search' || $path[0] == 'cari') {include_once "page_search.php"; die();}
	if (strlen($path[1]) < 6) {include_once "page_list.php"; die();}
	if (strlen($path[1]) > 6) {
		if ($path[2] == 'edit') {include_once "page_edit.php"; die();}
		if ($path[2] == 'del') {include_once "page_del.php"; die();}
		include_once "page_detail.php"; die();
	}
}

?>