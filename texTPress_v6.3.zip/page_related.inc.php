<?php
include_once "functions.inc.php";

		$row_related = $row_global;

		foreach ($row_related as $column_related) {
			$column_related[5] = date('d M Y',strtotime($column_related[5]));
		}

	$ar_related_pattern = explode('-',$path[1]); 
	$related_pattern = "";
	foreach ($ar_related_pattern as $item_related) {
		if (strlen($item_related) > 5) {
			$related_pattern .= $item_related."|"; 
			}
	}
	$related_pattern = substr($related_pattern,0,-1);
	
$i = 0;
foreach ($row_related as $column_related) {
	if (preg_match('/'.$related_pattern.'/i',$column_related[1]) && strlen($column_related[3]) > 11 && !stristr($column_related[1],$path[1])) {
		$i++;
		}
	}
		$total_related = $i;
	
	$pola0 = in_string('<!--start related-->','<!--end related-->',$template);
	$list = "";
$count_related = 0;
	for ($i=0;$i<$total_related;$i++) {
		$pola1 = str_replace('[]','['.$i.']',$pola0);
		$list .= $pola1;
		if ($i >= 4 || $i >= $total_related) {break;}
	}
		$template = str_replace($pola0,$list,$template);


$count_related = 0;
foreach ($row_related as $column_related) {
	if (preg_match('/'.$related_pattern.'/i',$column_related[1]) && strlen($column_related[3]) > 11 && !stristr($column_related[1],$path[1])) {
			$content_img = in_string('img src="','"',$column_related[4]);
			if ($content_img == '') {$content_img = $abs_url."images/no_image.png";}
			$template = str_replace('{related_permalink['.$count_related.']}',$abs_url.$column_related[2].'/'.$column_related[1],$template);
			$template = str_replace('{related_date['.$count_related.']}',$column_related[5],$template);
			$template = str_replace('{related_title['.$count_related.']}',stripslashes($column_related[3]),$template);
			$template = str_replace('{related_content['.$count_related.']}',stripslashes($column_related[4]),$template);
			$template = str_replace('{related_img['.$count_related.']}',$content_img,$template);
			$template = str_replace('{related_price['.$count_related.']}',$column_related[6],$template);
			$count_related++;
		if ($count_related > 4 || $count_related > count($row_related)) {break;}
	}
}
	if ($total_related <= 0) {
		$template = str_replace('<!--start related--><!--end related-->',$error_related,$template);
	}


?>