<?php
include_once "functions.inc.php";

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = ucfirst($path[0])." ".$setting[SiteConfig][2];
$desc = $setting[Meta][3];
$kw = $path[0]." ".$setting[Meta][4];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);


if (!file_exists('files/template_home.php')) {$template = access_url($abs_url.'template_home.php');}
if (file_exists('files/template_home.php')) {$template = access_url($abs_url.'files/template_home.php');}



//include_once "page_headline.inc.php";
include_once "page_sample.inc.php";
include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";
include_once "page_global.inc.php";
//include_once "page_galeri.inc.php";
//include_once "page_channel.inc.php";


$page_type = in_string('<!--start ','-->',$template);
if ($_COOKIE['username'] != '' && stristr($template,'{'.trim($page_type).'_content[]}')) {
	$template = str_replace('{'.trim($page_type).'_content[]}','<a href="'.$abs_url.$page_type.'/add"><span class="glyphicon glyphicon-edit"></span> Edit</a>',$template);
	$template = str_replace('{'.trim($page_type).'_title[]}','',$template);	
}
if ($_COOKIE['username'] != '' && stristr($template,'{'.trim($page_type).'_title[]}')) {
	$template = str_replace('{'.trim($page_type).'_title[]}','<a href="'.$abs_url.$page_type.'/add"><span class="glyphicon glyphicon-edit"></span> Edit</a>',$template);
	$template = str_replace('{'.trim($page_type).'_content[]}','',$template);	
}

if ($_COOKIE['username'] != '' && stristr($template,'<!--edit blog-->')) {
	$template = str_replace('<!--edit blog-->','<a href="'.$abs_url.'blog"><span class="glyphicon glyphicon-edit"></span> Edit</a>',$template);
}

echo $template;

if ($_GET['q'] == 'login') {$pesan = $alert_must_login;}
if ($_GET['q'] == 'logout') {$pesan = $alert_logout;}


?>
<?php
include_once "process_last.inc.php";
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
}
?>
