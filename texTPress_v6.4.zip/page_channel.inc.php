<?php
include_once "functions.inc.php";

		$row_channel_news = read_db('files/channel-news.txt',1,11);
		
		foreach ($row_channel_news as $column_channel_news) {
			$column_channel_news[5] = date('d M Y',strtotime($column_channel_news[5]));
		}

	$pola0 = in_string('<!--start channel-news-->','<!--end channel-news-->',$template);
	$list = "";
$count_channel_news = 0;
	for ($i=0;$i<count($row_channel_news);$i++) {
		$pola1 = str_replace('[]','['.$i.']',$pola0);
		
		//costumize template
		if ($i >= 1) {
			$pola1 = str_replace('<div class="col-md-8">','<div class="col-md-4">',$pola1);
			//$pola1 = str_replace('<iframe width="280" height="200"','<img width="140" height="100"',$pola1);
			}

		$list .= $pola1;
		//custom template
		if ($path[0] == '' && $i >= 2) {break;}		
		
		if ($i >= 4 || $i >= count($row_channel_news)) {break;}
	}

		$template = str_replace($pola0,$list,$template);


$count_channel_news = 0;
foreach ($row_channel_news as $column_channel_news) {
	if (strlen($column_channel_news[3]) > 11 ) {
		//custom template
			$content_img = in_string('src="','"',$column_channel_news[4]);
			if (stristr($content_img,'youtube')) {$content_img = str_replace('www.youtube.com/embed/','img.youtube.com/vi/',$content_img).'/0.jpg';}
			//if ($content_img == '') {$content_img = $abs_url."images/no_image.png";}
$content = strip_tags(stripslashes($column_channel_news[4]),"<br>");
			$template = str_replace('{channel-news_permalink['.$count_channel_news.']}',$abs_url.'channel-news/'.$column_channel_news[1],$template);
			$template = str_replace('{channel-news_date['.$count_channel_news.']}',$column_channel_news[2],$template);
			$template = str_replace('{channel-news_title['.$count_channel_news.']}',stripslashes($column_channel_news[3]),$template);
			$template = str_replace('{channel-news_content['.$count_channel_news.']}',$content,$template);
			$template = str_replace('{channel-news_img['.$count_channel_news.']}',$content_img,$template);
			$template = str_replace('{channel-news_price['.$count_channel_news.']}',$column_channel_news[6],$template);
			$count_channel_news++;
		if ($count_channel_news > 2 || $count_channel_news > count($row_channel_news)) {break;}
	}
}
	if ($status_channel_news != 'OK') {
		$status_channel_news = $error_channel_news;
	}

?>