<?php
// bahasa Indonesia
$btn_add = "Tambah";
$btn_edit = "Ubah";
$btn_del = "Hapus";
$btn_send = "Kirim";
$btn_send_comment = "Kirim komentar";
$btn_save = "Simpan";
$btn_choice = "Pilihan anda:";
$btn_activate = "Aktivasi";

$first = "Awal";
$prev = "Sebelumnya";
$next = "Berikutnya";
$last = "Akhir";

$comment_name = "Nama anda";
$comment_identity = "Email atau URL";
$comment_message = "Pesan anda";

$administration = "Administrasi ";
$text_date = "Tanggal";
$text_title = "Judul";
$text_content = "Isi";
$text_summary = "Ringkas pada paragraf pertama";
$text_price = "Harga";
$text_content_note = "Catatan";
$text_content_note_info = "Catatan hanya bisa dilihat oleh Admin saat editing";
$text_activate = "Masukkan kode aktivasi untuk domain ".$domain[host];
$text_activation_note = "Anda dapat copy paste kode lisensi tersebut untuk membuat website di subdomain";

$post = "Tampilkan";
$draft = "Konsep (tersembunyi)";

$title_site_setting = "Seting website";
$text_meta_title = "Nama website";
$text_color_base = "Warna dasar";

$text_administration = "Administrasi";
$text_comment = "Komentar";
$text_more = "Selengkapnya";

$text_related = "Terkait";
$text_new = "Baru";
$text_recent = "Terkini";
$text_popular = "Populer";

$text_search = "Cari";
$text_subscribe = "Berlangganan";
$text_category = "Kategori halaman";

$text_signup = "Daftar";
$text_login = "Login";
$text_lost_password = "Lupa password";
$text_change_password = "Ubah password";
$text_your_email = "Email anda";
$text_please = "Silakan";
$text_remember = "Ingat saya";
$text_lost_password_question = "Anda tidak bisa login karena lupa password?";
$text_please_reset = "Silahkan reset password anda jika tidak bisa login berkali-kali";
$text_reset_note = "<p>Setelah melakukan reset password, buka email anda untuk memastikan bahwa permintaan reset password ini benar-benar anda sebagai pemilik akun.</p>
                <p>Jika anda tidak menemukan email di inbox, cobalah untuk cek email di bagian spam. Mohon untuk menekan tombol bukan spam agar memudahkan anda di lain waktu</p>";
$text_writable = "Folder bisa ditulisi";
$text_not_writable = "Folder tidak bisa ditulisi";
$text_textpress_contact = "Pin BB | 7CAEDDCC <br>WhatApp / Telegram | +6283840273173 <br>YM | cs.tetuku";

$text_tp_name = "Nama template";
$text_tp_thumb = "Gambar ilustrasi template";
$text_tp_preview = "Preview tampilan";
$text_tp_feature = "Fitur template";
$text_tp_price = "Harga";
$text_tp_owner = "Url halaman pembelian";

$error_related = "Belum ada informasi terkait";
$error_widget = "Belum ada data";

$alert_logout = "Anda berhasil logout";
$alert_must_login = "Anda harus login untuk mengakses halaman ini";
$alert_login_fail = "Login gagal ! \\nPastikan kombinasi email dan password yang anda masukkan benar";
$alert_email_not_registered = "Email anda belum terdaftar, silahkan isi formulir pendaftaran.\\nLakukan sekarang?";
$alert_save = "Data berhasil disimpan";
$alert_sent = "Data berhasil dikirimkan";
$alert_not_pass = "Data sudah ada, silakan cek";
$alert_new_comment = "Komentar baru di halaman";
$alert_not_textpress = "Apakah ini template untuk texTPress? Sepertinya bukan";
$alert_del = "Apakah anda yakin akan menghapus?";

$text_email_contact = "Pesan anda di website ";
?>