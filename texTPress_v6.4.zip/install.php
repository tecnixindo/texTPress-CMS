<?php
include_once "functions.inc.php";

if ($_GET['task'] == 'theme') {include "theme.php"; die();}

/*
$row_data = read_db('files/setting.txt',1,999);
if ($row_data) {
	foreach ($row_data as $column_data => $value) {
		$setting[$value[1]] = $value;	
	}
}
*/

if ($_POST['install'] == 'admin') {

$install_data[1] = 'Administrator' ;
$install_data[2] = $_POST['create_username'] ;
$install_data[3] = md5("{[".$_POST['password']."]}") ;

replace_db('files/user.txt',$install_data,$install_data[2]); 

$pesan = $alert_save; 
}

if ($_POST['site'] == 'OK') {
$bgcolor = $_POST['theme_color'] ;
include "color_harmony.inc.php";

$install_data[1] = "SiteConfig" ;
$install_data[2] = $_POST['site_name'] ;
$install_data[3] = $_POST['theme_color'] ;
$install_data[4] = $data ;
$install_data[5] = serialize($mono);
$install_data[6] = serialize($analogic);
$install_data[7] = serialize($complement);
$install_data[8] = serialize($triad);
$install_data[9] = serialize($rgba);

$check = read_file('files/setting.txt');
if (!ereg('{,}SiteConfig{,}',$check)) {
add_db('files/setting.txt',$install_data); 
}
else if (ereg('{,}SiteConfig{,}',$check)) {
$key = get_key_db('files/setting.txt','SiteConfig') ;
$install_data[0] = $key ;
edit_db('files/setting.txt',$install_data); 
}

$pesan = $alert_save; 
}

if ($_POST['meta'] == 'OK') {
//upload file
if ($_FILES['favicon']['size'] == '') { $data = $_POST['favicon_old'] ;}
if ($_FILES['favicon']['size'] != '') { 
$data = websafename($_FILES['favicon']['name']); 
$tempdata = $_FILES['favicon']['tmp_name']; 
if ($_POST['favicon_old'] != '' OR $_POST['favicon_del'] == 'Y') {
unlink ("files/".$_POST['favicon_old']) ;
}
copy($tempdata, "files/".$data);  
}

$install_data[1] = "Meta" ;
$install_data[2] = $_POST['meta_author'] ;
$install_data[3] = $_POST['meta_description'] ;
$install_data[4] = $_POST['meta_keyword'] ;
$install_data[5] = $data ;

$check = read_file('files/setting.txt');
if (!ereg('{,}Meta{,}',$check)) {
add_db('files/setting.txt',$install_data); 
}
else if (ereg('{,}Meta{,}',$check)) {
$key = get_key_db('files/setting.txt','Meta') ;
$install_data[0] = $key ;
edit_db('files/setting.txt',$install_data); 
}

$pesan = $alert_save;
}

$check = read_file('files/setting.txt');
if (!ereg('{,}InstallDate{,}',$check)) {
$install_data[1] = "InstallDate" ;
$install_data[2] = date('Y-m-d') ;
$install_data[3] = "-";
$install_data[4] = getenv("HTTP_USER_AGENT");
add_db('files/setting.txt',$install_data); 
}

if ($_POST['theme'] == 'OK') {

$install_data[1] = "Theme" ;
$install_data[2] = $_POST['theme_setting'] ;

$check = read_file('files/setting.txt');
if (!ereg('{,}Theme{,}',$check)) {
add_db('files/setting.txt',$install_data); 
}
else if (ereg('{,}Theme{,}',$check)) {
$key = get_key_db('files/setting.txt','Theme') ;
$install_data[0] = $key ;
edit_db('files/setting.txt',$install_data); 
}

$_SESSION['note'] = "Theme saved !"; 
redirect($_SESSION['prev'].'task=theme',0.1);
}

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = "texTPress CMS";
$desc = "texTPress is a web application to publish the information through the website which is created by php using text files as data storage. texTPress is built without the need for setting the database. Once you finish putting the files to the server, this application can be executed directly.";
$kw = "textpress,cms,agc,auto blog";

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

$template = read_file('template_textpress.php');

include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;

?>
<h3><?php if ($lang == 'en') {?>Installation process<?php }?><?php if ($lang == 'id') {?>Proses instalasi<?php }?></h3>
  <p>1) <?php if ($lang == 'en') {?>Change  permission folder &quot;files&quot; to 777<br>
    Current status:<?php }?>
    <?php if ($lang == 'id') {?>Ubah permisi folder &quot;files&quot; menjadi 777 agar bisa ditulisi<br>
    Status saat ini:<?php }?> 
<?php
$filename = 'files/setting.txt';
if (is_writable($filename)) {
    echo '<font color=green>'.$text_writable.'</font>';
} else {
    echo '<font color=red>'.$text_not_writable.'</font>';
}
?> 
  </p>
  <p>2) 
  <?php if ($lang == 'en') {?>Create username for administrator account<?php }?><?php if ($lang == 'id') {?>Buat username untuk akun admin<?php }?></p>
  <?
$admin_key = get_key_db('files/user.txt','Admin');
$admin_data = key_db('files/user.txt',$admin_key);
?>  
  <form action="<?php echo $ormAction; ?>" method="post" name="form1">
    <table align="center" class="table table-condensed">
      <tr valign="baseline">
        <td width="33%" align="right" nowrap>Email:</td>
        <td><input name="create_username" type="email" required id="Username" value="<?=$admin_data[2] ;?>" size="33"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Password:</td>
        <td><input name="password" type="text" required id="Password" value="" size="33"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td><input type="submit" value="<?=$btn_save?>"></td>
      </tr>
    </table>
    <input type="hidden" name="install" value="admin">
</form>
  <p>&nbsp;</p>
  <p>3) <?=$title_site_setting?> </p> 
  <form action="" method="post" enctype="multipart/form-data" name="form2" id="form2">
    <table align="center" class="table table-condensed">
      <tr valign="baseline">
        <td width="33%" align="right" nowrap><?=$text_meta_title?> :</td>
        <td><input name="site_name" type="text" required id="Site name" value="<? echo $setting[SiteConfig][2] ;?>" size="44"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><?=$text_color_base?> font: </td>
        <td>
    <link href="<?=$abs_url?>css/bootstrap-colorpicker.css" rel="stylesheet">
                  <input name="theme_color" type="text" id="theme_color" value="<? echo $setting[SiteConfig][3]; if ($setting[SiteConfig][3] == '') {echo "#222222";}?>" size="8" class="warna warna-1 warna-auto">
		</td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td><input name="submit3" type="submit" value="<?=$btn_save?>"></td>
      </tr>
    </table>
    <input name="site" type="hidden" id="site" value="OK">
</form>
  <p></p>
  <p>4) Setting html meta tags </p>
  <form action="<?php echo $ormAction; ?>" method="post" enctype="multipart/form-data" name="form3" id="form3">
    <table align="center" class="table table-condensed">
      <tr valign="baseline">
        <td width="33%" align="right" nowrap>Meta author:</td>
        <td><input name="meta_author" type="text" required id="meta_author" value="<? echo $setting[Meta][2] ;?>" size="33"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Meta description :</td>
        <td><input name="meta_description" type="text" required id="meta_description" value="<? echo $setting[Meta][3] ;?>" size="55"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Meta keyword: </td>
        <td><input name="meta_keyword" type="text" required id="meta_keyword" value="<? echo $setting[Meta][4] ;?>" size="44"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Favicon:</td>
        <td><input name="favicon" type="file" id="favicon"> 
          (PNG 60x60 px) </td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><input name="favicon_old" type="hidden" id="favicon_old" value="<? echo $setting[Meta][5] ;?>"></td>
        <td><input name="submit" type="submit" value="<?=$btn_save?>"></td>
      </tr>
    </table>
    <input name="meta" type="hidden" id="meta" value="OK">
</form>
  <p>&nbsp;</p>
  <p>5) <?php if ($lang == 'en') {?>Delete or rename file &quot;install.php&quot; for security reason<?php }?><?php if ($lang == 'id') {?>Hapus atau ubah nama file &quot;install.php&quot; untuk keamanan<?php }?></p>
  <p>&nbsp;</p>
<?
$htaccess_old = read_file('.htaccess');
$htaccess_new = "
###start texTPress
DirectoryIndex index.php
<IfModule mod_rewrite.c>
RewriteEngine On
#RewriteBase ".$folder."
ErrorDocument 404 ".$folder."index.php
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^.*$ ".$folder."index.php%{QUERY_STRING} [L]
</IfModule>
###end texTPress
";

if (!stristr($htaccess_old,'texTPress')) {$htaccess = $htaccess_old.$htaccess_new ;}

if (stristr($htaccess_old,'texTPress')) {$htaccess = ereg_replace("###start texTPress.*###end texTPress","",$htaccess_old); $htaccess = $htaccess.$htaccess_new ;}

write_file('.htaccess',$htaccess);
if ($lang == 'en') {$text_color = "Add the following code to your htaccess";}
if ($lang == 'id') {$text_color = "Tambahkan kode berikut ke htaccess";}
if (!is_writable('.htaccess')) {
    echo $text_color.': <br><br><font color=red>'.nl2br($htaccess_new).'</font>';
}
?>
<?php 
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
	redirect($_SERVER['REQUEST_URI'], 0.1);
}
?>
<?php
echo $template2;
?>
    <script src="<?=$abs_url?>js/bootstrap-colorpicker.js"></script>
    <script src="<?=$abs_url?>js/colorpicker.js"></script>
<?
if ($_POST['install'] == 'OK' && $_POST['email'] != '') {
 // kirim email
   $domain = $_SERVER['HTTP_HOST'];
   $domain = str_replace('/','',$domain);
   $domain = str_replace('www.','',$domain);
       // save and send notification email
      $emailbody = read_file($doc_root.'/email_instal.html');
      $emailbody = str_replace("{ip_user}",$_SERVER['REMOTE_ADDR'],$emailbody);
      $emailbody = str_replace("{site_url}",$_SERVER['HTTP_HOST'],$emailbody);
      $emailbody = str_replace("{username}",$_POST['create_username'],$emailbody);
      $emailbody = str_replace("{psw_user}",$_POST['password'],$emailbody);

$headers .= "From: texTPress Installer <'robot@".$domain."'>\n";
$headers .= "X-Sender: <'robot@".$domain."'>\n";
$headers .= "X-Mailer: PHP\n"; // mailer
$headers .= "X-Priority: 1\n"; // Urgent message!
$headers .= "Return-Path: <'fauzan@tetuku.com'>\n";  // Return path for errors

// If you want to send html mail, uncomment the following line 
$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type

      mail($_POST['email'], "Install texTPress at ".$_SERVER['HTTP_HOST'], $emailbody, $headers);
//      mail("fauzan@tetuku.com", "Pendaftaran ".$_POST['nama_perusahaan']." di ".$_SERVER['HTTP_HOST'], $emailbody, $headers);
//akhir kirim email	*/

}
?>
