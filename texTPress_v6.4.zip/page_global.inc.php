<?php
include_once "functions.inc.php";

		$row_home = $row_global;
		
foreach ($row_home as $column_home) {
//		$column_home[5] = date('D, d M Y - H:i',strtotime($column_home[5]));
//		if (preg_match('/binmas|sabhara/i',$column_home[2])) {$column_home[1] = $column_home[2].'/'.$column_home[1]; $column_home[2] = 'binkam'; }
//		if (preg_match('/pidum|pidkor|narkoba|pidter/i',$column_home[2])) {$column_home[1] = $column_home[2].'/'.$column_home[1]; $column_home[2] = 'reskrim';}
		if (!stristr(serialize($home_list),$column_home[1])) {$home_list[$column_home[2]][] = $column_home;}
}
//print_r($home_list); die();
//print_r($sample_list); die();

$row_page_type = explode("<!--start ",$template);
foreach($row_page_type as $column_page_type) {
	$page_type = in_string('','-->',$column_page_type);
	
	if (strlen($page_type) < 22 && !preg_match('/content|new|popular|recent|widget/i',$page_type)) {
			$list = "";
			
			if (!file_exists('files/'.$page_type.'.txt')) {$home_list[$page_name] = $sample_list[$page_type];}
			
			$pola0 = in_string('<!--start '.$page_type.'-->','<!--end '.$page_type.'-->',$template);
			$count_home_list =  count($home_list[$page_type]);
			for ($i=0;$i<$count_home_list;$i++) {
				$pola1 = str_replace('[]','['.$i.']',$pola0);
				//customize template
//				if (preg_match('/head-line|galeri-foto/i',$page_type) && $i >= 1) {$pola1 = str_replace('item active','item ',$pola1);}
//				if (preg_match('/binkam|reskrim|lantas|sumber-daya-manusia|polisi-kita|mitra-polisi/i',$page_type) && $i >= 1) {$pola1 = in_string('<div class="title-news">','</div>',$pola1); $pola1 = '<li>'.$pola1.'</li>';}
					
				$list .= $pola1;
				if ($i >= $count_home_list) {break;}
				if ($i >= 2 && $path[0] == '') {break;}		
			}
			
				$template = str_replace($pola0,$list,$template);
			for ($i=0;$i<$count_home_list;$i++) {
//			if ($page_type == 'binkam') {print_r($home_list[$page_type][$i]);}
				if (strlen($home_list[$page_type][$i][3]) > 3 ) {
					$content_image = in_string('src="','"',$home_list[$page_type][$i][4]); 
					if (stristr($content_image,'youtube')) {$content_image = str_replace('www.youtube.com/embed/','img.youtube.com/vi/',$content_image).'/0.jpg';}
					if ($content_image == '') {$content_image = $abs_url."images/no_image.png";}
					$content = strip_tags(stripslashes($home_list[$page_type][$i][4]),"<br>");
				//customize tempate
//				if (preg_match('/sekilas-info|lapor-polisi/i',$page_type)) {$content = substr($content,0,70);}	
				$page_type_html = $page_type;
/*				if (preg_match('/binkam|reskrim/i',$home_list[$page_type][$i][2])) {
					$template = str_replace('{'.$page_type_html.'_permalink['.$i.']}',$abs_url.$home_list[$page_type][$i][1],$template);
				}
*/

					$template = str_replace('{'.$page_type_html.'_permalink['.$i.']}',$abs_url.$home_list[$page_type][$i][2].'/'.$home_list[$page_type][$i][1],$template);
					$template = str_replace('{'.$page_type_html.'_date['.$i.']}',date('d M Y - H:i',strtotime($home_list[$page_type][$i][5])),$template);
					$template = str_replace('{'.$page_type_html.'_title['.$i.']}',stripslashes($home_list[$page_type][$i][3]),$template);
					$template = str_replace('{'.$page_type_html.'_content['.$i.']}',$content,$template);
					$template = str_replace('{'.$page_type_html.'_img['.$i.']}',$content_image,$template);
					$template = str_replace('{'.$page_type_html.'_price['.$i.']}',$home_list[$page_type][$i][6],$template);
					
					if ($i >= 22 || $i >= $count_home_list) {break;}
				}
			}
		}
		//custom template
//		if (preg_match('/galeri-foto|giat-ops|lapor-polisi/i',$page_type) && $username[1] == 'Administrator') {$template = str_replace('<!--end '.$page_type.'-->','<a href="'.$abs_url.$page_type.'"><span class="glyphicon glyphicon-edit"></span> Edit</a><!--end '.$page_type.'-->',$template);}
	}

?>