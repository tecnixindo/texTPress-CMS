<?php
//include_once "functions.inc.php";

if (!stristr($username[1],'Admin')) {
redirect($abs_url.'?q=login'); die();
}

?>