<? 
session_start();
//error_reporting(0);
//$_SESSION[sesi] = '';
print_r($_SESSION[sesi]); die();

if ($_POST['Submit'] != '') {
$flickr_title = $_POST['title'];
$flickr_desc = $_POST['desc'];
include_once"flickr.add.php";
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>File Browser</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Pragma" content="no-cache" />
<script language="javascript" type="text/javascript" src="../../tiny_mce_popup.js"></script>
	<link rel="stylesheet" type="text/css" media="all" href="../../themes/advanced/skins/default/dialog.css" /><link rel="stylesheet" type="text/css" media="all" href="css/style_tinybrowser.css.php" />
<script language="javascript" type="text/javascript" src="js/tinybrowser.js.php?"></script>
</head>
<body>
<?
if (count($_SESSION[sesi]) > 1 || $_POST['Submit'] != '') {
?>
<div class="panel_wrapper">
<div id="general_panel" class="panel currentmod">
<fieldset>
<legend>Browse Files</legend>
<? 
foreach ($_SESSION[sesi] as $kolom) {
?>
<div class="img-browser">
<a href="#" onclick="selectURL('<?=$kolom[src]?>');" title="<?=$kolom[title]?>">
<img src="<?=$kolom[thumb]?>"  />
<div class="filename"><?=$kolom[title]?></div>
</a>
</div>
<? }?>
</fieldset>
</div>
<? }
?>
<form name="passform"><input name = "fileurl" type="hidden" value= "" /></form>
<form action="" method="post" enctype="multipart/form-data" name="form1">
<p>
  Judul foto:<br>
  <input name="title" type="text" id="title" size="33">
</p>
<p>
  Keterangan foto:<br>
  <textarea name="desc" cols="55" rows="4" id="desc"></textarea>
</p>
  File foto:<br>
  <input type="file" name="file">
  <input type="submit" name="Submit" value="Submit">
</form>
</body>
</html>
