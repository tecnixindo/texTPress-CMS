<?php
// script by Fauzan for petarumahjogja.com - tecnixindo@gmail.com
// seting variabel
// $flickr_title
// $flickr_desc

require_once("flickr.class.php");//chage to your directory
session_start();
$_SESSION['flickr_session_upload'] = "72157632866825659-539ab5d42b0724f6";

$fk=new curlflickr;
if ($_SESSION['flickr_session_upload'] == '') {include_once "flickr.login.php";}

  $flickr_url=$fk->uploadsingle($_FILES['file']['tmp_name'],"all",$flickr_title,$flickr_desc);//a long setting ,see the function yourself 

// return	"square"	"thumbnail"		"small"		"medium"	"large"		"original"

/*
print_r($flickr_url);
echo "<hr>";
print($flickr_url[);
echo "<hr>";
  print "<img src='".$flickr_url[thumbnail]."' />";
  print "<img src='".$flickr_url[original]."' />";
echo "<hr>";
  print "<img src='".$flickr_url['thumbnail']."' />";
  print "<img src='".$flickr_url['original']."' />";
echo "<hr>";
  print "<img src='".$flickr_url['_o']."' />";
  print "<img src='".$flickr_url['_t']."' />";
echo "<hr>";
  print "<img src='".$flickr_url[_o]."' />";
  print "<img src='".$flickr_url[_t]."' />";
echo "<hr>";
  print_r($flickr_url['thumbnail']);
echo "<hr>";
  print_r($flickr_url[thumbnail]);
  */

if ($flickr_url) {
	foreach ($flickr_url as $column => $value) {
		$flickr[strtolower(preg_replace('/[^A-Za-z0-9]/', '_',$value[label]))] = $value;
	}
}
$i = count($_SESSION[sesi])+1;
$_SESSION[sesi][$i][title] = $_POST['title'];
$_SESSION[sesi][$i][thumb] = $flickr[thumbnail][source];
$_SESSION[sesi][$i][src] = $flickr[medium][source];
?>