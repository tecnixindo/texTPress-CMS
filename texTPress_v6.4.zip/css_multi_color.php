<?php
include_once "functions.inc.php";

// Check color list at file color_harmony_list.php
		$color_key = get_key_db('files/setting.txt', 'SiteConfig');
		$color_detil = key_db('files/setting.txt',$color_key);

// harmoni warna
$mono = unserialize($color_detil[5]);
$analogic = unserialize($color_detil[6]);
$complement = unserialize($color_detil[7]);
$triad = unserialize($color_detil[8]);
$rgba = unserialize($color_detil[9]);

?>
<style type="text/css">

.navbar-inverse {
	background-color: <?=$mono[0]?>;
}

.navbar-header a:visited {
	color: <?=$mono[3]?>;
}

.navbar-nav li a:link {
	color: <?=$mono[3]?>;
}

.navbar-nav li a:visited {
	color: <?=$mono[3]?>;
}

.navbar-nav li ul li a:link {
	color: <?=$mono[2]?>;
}

.navbar-nav li ul li a:visited {
	color: <?=$mono[2]?>;
}

.nav-tabs a {
	color: <?=$mono[1]?>;	
	background-color: <?=$mono[4]?>;	
}

.thumb-left img{
	min-width:200px;
	max-width:320px;
	height:auto;
	background-color: #DEDEDE;
	margin: 12px;
	padding: 6px;
	clear: left;
	float: left;
	border: 1px solid #999;
}

.thumb-full img{
	width: 100%;
	height: auto;
	padding-bottom: 9px;
}

.container a {
	color: <?=$mono[4]?>;	
}

.container a:hover {
	color: <?=$mono[2]?>;
	text-decoration: underline;
}
</style>