<?
//session_start();
include_once "functions.inc.php";

$row_stats = read_db('files/stats.txt',1,100);

// untuk di olah di meta, keyword pisahkan dengan spasi
$desc = "Statistik pengunjung";
$kw = "statistik kunjungan";
?><!doctype html>
<html>
<head>
<?php include "template_meta.inc.php"; ?>
<title>Statistik</title>
</head>

<body>
<?php include "template_header.inc.php";?>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<div class="container">
  <div class="row">
		    	<div class="col-md-12">
                <div align="right"><p><a href="http://www.histats.com/viewstats/?act=2&sid=2768439" class="btn btn-primary btn-xs" role="button">Lihat Detil</a></p></div>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <? 
$i = 0;
$zebra = - 1;
foreach ($row_stats as $column_stats) {
$zebra = $zebra * (- 1) ;
$i = $i + 1;
?>
  <tr align="left" valign="top" <? if ($zebra > 0) {echo 'bgcolor="#DDDDDD"';} else if ($zebra < 0) {echo 'bgcolor="#EEEEEE"';}?>>
    <td width="50%"><? echo date('l, d F Y - H:i:s',strtotime($column_stats[1])); ?></td>
    <td width="40%"><? echo $column_stats[3]; ?></td>
    <td width="0%" align="right"><? echo $i;?></td>
  </tr>
  <tr align="left" valign="top" <? if ($zebra > 0) {echo 'bgcolor="#DDDDDD"';} else if ($zebra < 0) {echo 'bgcolor="#EEEEEE"';}?> id="grs_bwh">
    <td colspan="3">
	<? echo $column_stats[2]; ?>&nbsp;<br>      
      <a href="<? echo $column_stats[4]; if ($column_stats[4] == '') {echo "#";} ?>"><? echo $column_stats[4]; if ($column_stats[4] == '') {echo "<i>Direct visit</i>";} ?></a></td>
  </tr>
  <? 
}
?>
</table>
                </div>
		  </div>
</div>
          
</div><!--/.container--> 
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<?php include "template_footer.inc.php";?>
</body>
</html>
<?php
include_once "process_last.inc.php";
?>