<?php
include_once "../functions.inc.php";

$row_data = read_db('../files/setting.txt',1,999);
if ($row_data) {
	foreach ($row_data as $column_data => $value) {
		$setting[$value[1]] = $value;
	}
}

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>

<rss version="2.0"
	xmlns:content="http://purl.org/rss/1.0/modules/content/"
	xmlns:wfw="http://wellformedweb.org/CommentAPI/"
	xmlns:dc="http://purl.org/dc/elements/1.1/"
	xmlns:atom="http://www.w3.org/2005/Atom"
	xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
	xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
	>

	<channel>
	<title><?php echo $setting[SiteConfig][2] ;?></title>
	<atom:link href="<?=$abs_url?>rss/" rel="self" type="application/rss+xml" />
	<link><?=$abs_url?></link>
	<description><? echo $setting[Meta][3] ;?></description>
	<lastBuildDate><?php echo date('l, d F Y H:i:s');?> +0000</lastBuildDate>
	<language>en</language>
	<sy:updatePeriod>daily</sy:updatePeriod>
	<sy:updateFrequency>3</sy:updateFrequency>
	<generator><?=$abs_url?></generator>
<?php
$row_data = read_db('../files/content_stats.txt',1,20);
foreach ($row_data as $column_data) {
	if (strlen($column_data[5]) >= 5) {
?>	
     	 <item>
            <title><?php echo $column_data[3];?></title>
            <description><?php echo substr(strip_tags($column_data[4]),0,320);?></description>
            <link><?php echo $abs_url."/".$column_data[2]."/".$column_data[1];?></link>
            <guid isPermaLink="false"><?php echo $abs_url."/".$column_data[2]."/".$column_data[1];?></guid>
            <pubDate><?php echo date('l, d F Y H:i:s',strtotime($column_data[5]));?> -0400</pubDate>
        </item>
<?php
	}
}
?>		
	</channel>
</rss>
<!-- text-press.googlecode.com -->