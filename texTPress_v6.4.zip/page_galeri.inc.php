<?php
include_once "functions.inc.php";

		$row_galeri_foto = read_db('files/galeri-foto.txt',1,11);
		
		foreach ($row_galeri_foto as $column_galeri_foto) {
			$column_galeri_foto[5] = date('d M Y',strtotime($column_galeri_foto[5]));
		}


	$pola0 = in_string('<!--start galeri-foto-->','<!--end galeri-foto-->',$template);
	$list = "";
$count_galeri_foto = 0;
	for ($i=0;$i<count($row_galeri_foto);$i++) {
		$pola1 = str_replace('[]','['.$i.']',$pola0);
		
		//costumize template
		if ($i >= 1) {
			$pola1 = str_replace('item active','item ',$pola1);
			//$pola1 = str_replace('<iframe width="280" height="200"','<img width="140" height="100"',$pola1);
			}

		$list .= $pola1;
		//custom template
		if ($path[0] == '' && $i >= 2) {break;}		
		
		if ($i >= 4 || $i >= count($row_galeri_foto)) {break;}
	}

		$template = str_replace($pola0,$list,$template);


$count_galeri_foto = 0;
foreach ($row_galeri_foto as $column_galeri_foto) {
	if (strlen($column_galeri_foto[3]) > 4 ) {
		//custom template
			$content_img = in_string('src="','"',$column_galeri_foto[4]);
			//if (stristr($content_img,'youtube')) {$content_img = str_replace('www.youtube.com/embed/','img.youtube.com/vi/',$content_img).'/0.jpg';}
			if ($content_img == '') {$content_img = $abs_url."images/no_image.png";}
$content = strip_tags(stripslashes($column_galeri_foto[4]),"<br>");
			$template = str_replace('{galeri-foto_permalink['.$count_galeri_foto.']}',$abs_url.'galeri-foto/'.$column_galeri_foto[1],$template);
			$template = str_replace('{galeri-foto_date['.$count_galeri_foto.']}',$column_galeri_foto[2],$template);
			$template = str_replace('{galeri-foto_title['.$count_galeri_foto.']}',stripslashes($column_galeri_foto[3]),$template);
			$template = str_replace('{galeri-foto_content['.$count_galeri_foto.']}',$content,$template);
			$template = str_replace('{galeri-foto_img['.$count_galeri_foto.']}',$content_img,$template);
			$template = str_replace('{galeri-foto_price['.$count_galeri_foto.']}',$column_galeri_foto[6],$template);
			$count_galeri_foto++;
		if ($count_galeri_foto > 4 || $count_galeri_foto > count($row_galeri_foto)) {break;}
	}
}
	if ($status_galeri_foto != 'OK') {
		$status_galeri_foto = $error_galeri_foto;
	}

?>