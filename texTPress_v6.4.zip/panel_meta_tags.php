<?php include_once "ijin_user.inc.php";?>
<?php
include_once "functions.inc.php";

if ($_POST['meta'] == 'OK') {
//upload file
if ($_FILES['favicon']['size'] == '') { $data = $_POST['favicon_old'] ;}
if ($_FILES['favicon']['size'] != '') { 
$data = websafename($_FILES['favicon']['name']); 
$tempdata = $_FILES['favicon']['tmp_name']; 
if ($_POST['favicon_old'] != '' OR $_POST['favicon_del'] == 'Y') {
unlink ("files/".$_POST['favicon_old']) ;
}
copy($tempdata, "files/".$data);  
}

$install_data[1] = "Meta" ;
$install_data[2] = $_POST['meta_author'] ;
$install_data[3] = $_POST['meta_description'] ;
$install_data[4] = $_POST['meta_keyword'] ;
$install_data[5] = $data ;

$check = read_file('files/setting.txt');
if (!ereg('{,}Meta{,}',$check)) {
add_db('files/setting.txt',$install_data); 
}
else if (ereg('{,}Meta{,}',$check)) {
$key = get_key_db('files/setting.txt','Meta') ;
$install_data[0] = $key ;
edit_db('files/setting.txt',$install_data); 
}

$pesan = $alert_save;
}

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = $content_detil[3];
$desc = strip_tags(cuplik($content_detil[4],180));
$kw = $path[0]." ".$content_detil[3];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_detail.php')) {$template = read_file('template_detail.php');}
if (file_exists('files/template_detail.php')) {$template = read_file('files/template_detail.php');}


include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<p>&nbsp;</p>
<div class="row">
	<div class="col-md-7">
    	<h3>Meta tags</h3>
                  <p><?=$text_activate?></p>
<form action="<?php echo $ormAction; ?>" method="post" enctype="multipart/form-data" name="form3" id="form3">
    <table align="center" class="table table-condensed">
      <tr valign="baseline">
        <td width="33%" align="right" nowrap>Meta author:</td>
        <td><input name="meta_author" type="text" required id="meta_author" value="<? echo $setting[Meta][2] ;?>" size="33"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Meta description :</td>
        <td><input name="meta_description" type="text" required id="meta_description" value="<? echo $setting[Meta][3] ;?>" size="55"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Meta keyword: </td>
        <td><input name="meta_keyword" type="text" required id="meta_keyword" value="<? echo $setting[Meta][4] ;?>" size="44"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Favicon:</td>
        <td><input name="favicon" type="file" id="favicon"> 
          (PNG 60x60 px) </td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><input name="favicon_old" type="hidden" id="favicon_old" value="<? echo $setting[Meta][5] ;?>"></td>
        <td><input name="submit" type="submit" value="<?=$btn_save?>"></td>
      </tr>
    </table>
    <input name="meta" type="hidden" id="meta" value="OK">
</form>
                  <p>&nbsp;</p>
	</div>
</div>
<?php
echo $template2;
?>
<?php 
include_once "process_last.inc.php";
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
	redirect($_SERVER['REQUEST_URI'], 0.1);
}
?>
