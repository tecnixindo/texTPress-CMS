<?php
include_once "functions.inc.php";

		$row_new = $row_global;
		if (!file_exists('files/'.$path[0].'.txt') && $path[0] != '') {$row_new = read_db('files/sample_home.txt',1,99);}
		$row_new = array_sort($row_new,5,SORT_DESC);
		
		foreach ($row_new as $column_new) {
			$column_new[5] = date('d M Y',strtotime($column_new[5]));
		}

	$pola0 = in_string('<!--start new-->','<!--end new-->',$template);
	$list = "";
$count_new = 0;
	for ($i=0;$i<count($row_new);$i++) {
		$pola1 = str_replace('[]','['.$i.']',$pola0);
		
		//costumize template
		if ($i >= 1) {$pola1 = str_replace('item active','item ',$pola1);}

		$list .= $pola1;
		//custom template
		if ($path[0] == '' && $i >= 2) {break;}		
		
		if ($i >= 4 || $i >= count($row_new)) {break;}
	}
		$template = str_replace($pola0,$list,$template);


$count_new = 0;
foreach ($row_new as $column_new) {
	if (strlen($column_new[3]) > 11 && !preg_match('/galeri|widget|halaman/i',$column_new[2]) && !stristr($column_new[1],$path[1]) && !stristr($column_popular[1],$popular_inserted)) {
			$content_img = in_string('img src="','"',$column_new[4]);
			if ($content_img == '') {$content_img = $abs_url."images/no_image.png";}
			$content = strip_tags(stripslashes($column_new[4]),"<br>");
			$template = str_replace('{new_permalink['.$count_new.']}',$abs_url.$column_new[2].'/'.$column_new[1],$template);
			$template = str_replace('{new_date['.$count_new.']}',$column_new[5],$template);
			$template = str_replace('{new_title['.$count_new.']}',stripslashes($column_new[3]),$template);
			$template = str_replace('{new_content['.$count_new.']}',$content,$template);
			$template = str_replace('{new_img['.$count_new.']}',$content_img,$template);
			$template = str_replace('{new_price['.$count_new.']}',$column_new[6],$template);
			$count_new++;
			$new_inserted .= $column_new[1];
		if ($count_new > 4 || $count_new > count($row_new)) {break;}
	}
}
	if ($status_new != 'OK') {
		$status_new = $error_new;
	}

?>