<?
include_once "functions.inc.php";

$row_pingpong = read_db('files/server.txt',1,9999999);

$data_ping = 'nama_web='.$setting[SiteConfig][1].'&tuku_ping='.$abs_url;

// cek menu aktif
$jml_pingpong = count($row_pingpong);
if ($jml_pingpong <= 1) {$row_pingpong = array();}
shuffle($row_pingpong);
foreach ($row_pingpong as $column_pingpong) {
	if (strlen(trim($column_pingpong[1])) > 11) {$aksi_pingpong = trim($column_pingpong[1])."pingpong.php"; 
	break;
	
	}
}

// proses ping
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $aksi_pingpong);
	curl_setopt($curl, CURLOPT_FAILONERROR, false);
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_TIMEOUT, 30);
	curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (compatible; (teTuku v2012) +http://www.tetuku.com");
	curl_setopt($curl, CURLOPT_POSTFIELDS, $data_ping);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_ENCODING, "");
	$curlData = curl_exec($curl);
	curl_close($curl);
		
		
		//hapus link menu jika website sudah tidak aktif
		if (!stristr($curlData,'tuku_pong') && $jml_pingpong > 3) {
			$id_pingpong = preg_replace('/[^0-9]/', '',$column_pingpong[0]);
			del_db('files/server.txt',$id_pingpong);	
			}
		//echo $aksi_pingpong;


if ($_POST['tuku_ping'] != '') {
$cek_pingpong = read_file('files/server.txt');
$cek_url = access_url($_POST['tuku_ping']."/pingpong.php");
if (!stristr($cek_pingpong,$_POST['tuku_ping']) && stristr($cek_url,'tuku_pong') && !stristr($_POST['tuku_ping'],'localhost')) {$server[1] = $_POST['tuku_ping']; $server[2] = $_POST['nama_web'];  add_db('files/server.txt',$server);}
}

?>
<!-- tuku_pong -->
