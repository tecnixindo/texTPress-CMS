<?php
include_once "functions.inc.php";

$stats[1]		= date('Y-m-d H:i:s');
$stats[2]		= getenv("HTTP_USER_AGENT");
$stats[3]		= $_SERVER['REMOTE_ADDR'];
$stats[4]		= getenv("HTTP_REFERER");

if ($stats[4] != '' && !stristr($stats[4],$domain[host])) {
		add_db('files/stats.txt',$stats);
		}
/*
if ($_COOKIE['user_name'] != '') {
	if ($posisi == '') {$posisi = $path[0]." ".$path[1];}
	$stats_online[1]		= date('U',strtotime(date('Y-m-d H:i:s')));
	$stats_online[2]		= $_COOKIE['user_name'];
	$stats_online[3]		= $abs_url.$_SERVER['PHP_SELF'];
	$stats_online[4]		= $posisi;

	add_db('files/stats_akses.txt',$stats_online);
}
*/

?>